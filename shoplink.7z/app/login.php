<?php
$login = true; include('snippets/header.php') ?>

<div id="wrap">

	<main>

		<?php include('components/login.php') ?>


	</main>


</div>

<?php include('snippets/footer.php') ?>
