<?php include('snippets/header.php') ?>

<div id="wrap">

    <main>
        <?php include('components/current-order.php') ?>
    </main>

    <aside>
        <div class="wrapper">
            <?php include('components/promotions.php') ?>
        </div>
    </aside>

</div>

<?php include('snippets/footer.php') ?>
