<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0, maximum-scale=1">

  <title>Shoplink</title>
  <meta name="description" content="Shoplink">
  <meta name="keywords" content="Shoplink">

  <link rel="stylesheet" type="text/css" href="assets/css/app.css">

  <script
  src="https://code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
  <script src="assets/js/app.js"></script>

</head>
<body>

  <?php include('components/navbar.php') ?>

