<section class="landing">
	<ul>
		<li><a href="store.php">Ambient</a></li>
		<li><a href="store.php">Chill</a></li>
		<li><a href="store.php">Alcohol</a></li>
		<li>
			<a class="title" href="#">Value Centre</a>
			<ul class="sub-nav">
				<li><a href="store.php">Option 1</a></li>
				<li><a href="store.php">Option 2</a></li>
				<li><a href="store.php">Option 2</a></li>
				<li><a href="store.php">Option 2</a></li>
			</ul>
		</li>
	</ul>
</section>
