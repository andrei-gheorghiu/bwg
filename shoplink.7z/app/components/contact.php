<section class="contact">
	<h2>Contact</h2>
	<div class="contact-info">
		<h4>For IT Support:</h4>
		<a href="tel:014090351">t. 01 4090351</a>
		<a href="mailto:support@bwg.ie">t. support@bwg.ie</a>
	</div>
	<p>We welcome your feedback. if you have feedback to share with us, can you please email us on <a href="mailto:eazyorderalerts@bwg.ie">eazyorderalerts@bwg.ie</a></p>
</section>