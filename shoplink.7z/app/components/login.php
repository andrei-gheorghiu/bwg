<section class="login">
	<h1>Sign In</h1>
	<form class="form" method="post">
			<input type="text" class="field" placeholder="Username">
			<input type="text" class="field" placeholder="Password">
			<a class="forgot" href="#">Forgot your password?</a>
			<input class="btn" type="submit" data-saved="Saved!" value="Sign In">
			<input type="hidden" name="_csfr" value="eqUmknw9aZCiZVMPqoIqqB0KIVP5I3izIJksbgHCwaVWLW1Jj4qVAZJb9PuaGWun">
	</form>
</section>
