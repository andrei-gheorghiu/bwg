<section class="promotions">

	<div class="advert">
		<h4>Ancillary Product Promo</h4>
	</div>

	<div class="advert">
		<img src="http://placehold.it/400x400" alt="">
	</div>

</section>
	